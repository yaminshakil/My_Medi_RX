<?php

namespace App\Http\Requests\Patients;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class CreatePatientRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name'           => 'required|string|max:255',
            'email'          => 'nullable|email',
            'phone'          => 'required|string|max:20',
            'date_of_birth'  => 'nullable|date',
            'age'            => 'required|integer|min:0|max:150',
            'gender'         => 'nullable|in:male,female,other',
            'blood_group'    => 'nullable|string',
            'marital_status' => 'required|in:single,married,divorced,widowed',
            'address'        => 'nullable|string',
            'city'           => 'nullable|string',
            'profile_image'  => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
        ];
    }
}
