<?php

use App\Http\Middleware\EnsureActiveSubscription;
use App\Http\Middleware\EnsureAdminApiRole;
use App\Http\Middleware\EnsureProfileExists;
use App\Http\Middleware\HandleInertiaRequests;
use App\Http\Middleware\NotifyAdminsOfSuccessfulPost;
use App\Http\Middleware\NotifyFirebaseOfSuccessfulApiPost;
use App\Http\Middleware\RoleRedirectMiddleware;
use App\Http\Middleware\SetLocale;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Middleware\AddLinkHeadersForPreloadedAssets;
use Illuminate\Http\Request;
use Spatie\Permission\Middleware\PermissionMiddleware;
use Spatie\Permission\Middleware\RoleMiddleware;
use Spatie\Permission\Middleware\RoleOrPermissionMiddleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        channels: __DIR__.'/../routes/channels.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->append(NotifyAdminsOfSuccessfulPost::class);
        $middleware->api(append: [
            NotifyFirebaseOfSuccessfulApiPost::class,
        ]);

        $middleware->alias([
            'role'               => RoleMiddleware::class,
            'permission'         => PermissionMiddleware::class,
            'role_or_permission' => RoleOrPermissionMiddleware::class,
            'profile.exists'     => EnsureProfileExists::class,
            'role.redirect'      => RoleRedirectMiddleware::class,
            'subscription'       => EnsureActiveSubscription::class,
            'admin.api'          => EnsureAdminApiRole::class,
        ]);

        $middleware->web(append: [
            SetLocale::class,
            HandleInertiaRequests::class,
            AddLinkHeadersForPreloadedAssets::class,
        ]);

        //
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
