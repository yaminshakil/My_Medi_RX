import { Breadcrumbs } from '@/Components/breadcrumbs';
import { SidebarTrigger } from '@/Components/ui/sidebar';
import { type BreadcrumbItem as BreadcrumbItemType } from '@/types';
import { usePage } from '@inertiajs/react';
import { Globe } from 'lucide-react';
import NotificationBell from '@/Components/NotificationBell';
import LanguageSwitcher from '@/Components/LanguageSwitcher';


export function AppSidebarHeader({ breadcrumbs = [] }: { breadcrumbs?: BreadcrumbItemType[] }) {
    const { props } = usePage();
    return (
        <header className="flex h-16 shrink-0 items-center justify-between gap-2 border-b border-sidebar-border/50 px-6 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12 md:px-4">
            <div className="flex items-center gap-2">
                <SidebarTrigger className="-ml-1" />
                <Breadcrumbs breadcrumbs={breadcrumbs} />
            </div>
            <div className="flex items-center gap-2">
                <NotificationBell />
                <a target="__blank" href={props.ziggy.url}>
                    <Globe className="h-6 w-6 text-[var(--base-color)]" />
                </a>
                <LanguageSwitcher />
            </div>
        </header>
    );
}
