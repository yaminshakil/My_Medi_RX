<?php

use App\Http\Controllers\Api\V1\MenstrualCycle\MenstrualCycleController;
use App\Http\Controllers\Api\V1\Patient\MedicationAdherenceController;
use App\Http\Controllers\Api\V1\Patient\MedicationController;
use App\Http\Controllers\Api\V1\Patient\MedicationLogController;
use App\Http\Controllers\Api\V1\Patient\MedicationRefillController;
use App\Http\Controllers\Api\V1\Patient\MedicationReportController;
use App\Http\Controllers\Api\V1\Patient\MedicationScanController;
use App\Http\Controllers\Api\V1\Patient\MedicationScheduleController;
use App\Http\Controllers\Api\V1\Patient\PatientController;
use App\Http\Controllers\Api\V1\Patient\PatientDashboardController;
use App\Http\Controllers\Api\V1\Patient\PharmacyDirectoryController;
use App\Http\Controllers\Api\V1\Patient\PrescriptionPharmacyController;
use App\Http\Controllers\Api\V1\Patient\VaccinationController;
use App\Http\Controllers\Api\V1\Patient\VaccinationScheduleController;
use App\Http\Controllers\Api\V1\Patient\VitalTrendsController;
use App\Http\Controllers\Api\V1\PediatricDoseController;
use App\Http\Controllers\Api\V1\Pregnancy\PregnancyProfileController;
use App\Http\Controllers\Api\V1\Pregnancy\PregnancyStatusController;
use App\Http\Controllers\Api\V1\Pregnancy\PregnancySymptomLogController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:api', 'profile.exists'])->group(function () {
    Route::apiResource('/patients', PatientController::class)->except(['update']);
    // 2. Add an explicit POST route for updating the patient
    Route::post('/patients/{patient}', [PatientController::class, 'update']);
    Route::get('/patient/dashboard/overview', [PatientDashboardController::class, 'index']);
});

Route::prefix('/patient')
    ->middleware(['auth:api', 'profile.exists'])
    ->group(function () {
        Route::get('/pharmacies', [PharmacyDirectoryController::class, 'index'])
            ->name('pharmacies.index');
        Route::get('/dashboard', [
            PatientDashboardController::class, 'index',
        ]);
        Route::post('/prescriptions/{prescription}/pharmacy', [
            PrescriptionPharmacyController::class,
            'store',
        ])->name('prescriptions.pharmacy.store');

        Route::get(
            '/dashboard/heatmap',
            [PatientDashboardController::class, 'heatmap']
        );

        Route::get('/dashboard/day-details', [
            PatientDashboardController::class,
            'dayDetails',
        ]);

        // Dashboard and medication CRUD
        Route::get('/medications/dashboard', [
            MedicationController::class, 'dashboard',
        ]);
        Route::apiResource('medications', MedicationController::class);

        // Medication schedules
        Route::get('/medications/{medication}/schedules', [
            MedicationScheduleController::class, 'index',
        ]);
        Route::post('/medications/{medication}/schedules', [
            MedicationScheduleController::class, 'store',
        ]);
        Route::put('/medication-schedules/{schedule}', [
            MedicationScheduleController::class, 'update',
        ]);
        Route::delete('/medication-schedules/{schedule}', [
            MedicationScheduleController::class, 'destroy',
        ]);

        // Dose tracking
        Route::get('/medication-logs', [
            MedicationLogController::class, 'index',
        ]);
        Route::post('/medication-logs/{log}/taken', [
            MedicationLogController::class, 'taken',
        ]);
        Route::post('/medication-logs/{log}/skip', [
            MedicationLogController::class, 'skip',
        ]);
        Route::post('/medication-logs/{log}/snooze', [
            MedicationLogController::class, 'snooze',
        ]);

        // Adherence analytics
        Route::get('/medications/adherence', [
            MedicationAdherenceController::class, 'summary',
        ]);
        Route::get('/medications/adherence/calendar', [
            MedicationAdherenceController::class, 'calendar',
        ]);
        Route::get('/medications/adherence/streaks', [
            MedicationAdherenceController::class, 'streaks',
        ]);

        // Prescription scanning
        Route::post('/medications/scan/qr', [
            MedicationScanController::class, 'qr',
        ]);
        Route::post('/medications/scan/ocr', [
            MedicationScanController::class, 'ocr',
        ]);

        // Inventory
        Route::get('/medications/refills', [
            MedicationRefillController::class, 'index',
        ]);
        Route::post('/medications/{medication}/refill', [
            MedicationRefillController::class, 'store',
        ]);

        // Vaccinations
        Route::get('/vaccines', [
            VaccinationController::class, 'vaccines',
        ]);

        Route::get('/vaccinations', [
            VaccinationController::class, 'index',
        ]);
        Route::post('/vaccinations', [
            VaccinationController::class, 'store',
        ]);
        Route::get('/vaccinations/{record}', [
            VaccinationController::class, 'show',
        ]);
        Route::put('/vaccinations/{record}', [
            VaccinationController::class, 'update',
        ]);
        Route::delete('/vaccinations/{record}', [
            VaccinationController::class, 'destroy',
        ]);

        Route::apiResource(
            'vaccination-schedules',
            VaccinationScheduleController::class
        );

        // Reports
        Route::get('/medications/reports', [
            MedicationReportController::class, 'index',
        ]);
        Route::get('/medications/reports/pdf', [
            MedicationReportController::class, 'pdf',
        ]);

        // Vital Trands
        Route::get('dashboard/{id}/vitals-trends', [VitalTrendsController::class, 'getVitalsTrends']);
    });

Route::prefix('pediatric-dose')
    ->middleware('auth:api')
    ->group(function () {
        Route::get(
            '/medicines',
            [PediatricDoseController::class, 'medicines']
        );

        Route::post(
            '/calculate',
            [PediatricDoseController::class, 'calculate']
        );

        Route::get('/recent', [PediatricDoseController::class, 'recent']);
    });

Route::middleware('auth:api')
    ->prefix('pregnancy')
    ->group(function () {
        Route::get('/profile', [PregnancyProfileController::class, 'show']);
        Route::post('/profile', [PregnancyProfileController::class, 'store']);
        Route::post('/profile/deactivate', [PregnancyProfileController::class, 'deactivate']);

        Route::get('/status', PregnancyStatusController::class);
        Route::get('/symptoms', [PregnancySymptomLogController::class, 'index']);
        Route::post('/symptoms', [PregnancySymptomLogController::class, 'store']);
        Route::delete('/symptoms/{uuid}', [PregnancySymptomLogController::class, 'destroy']);
    });

Route::middleware('auth:api')
    ->group(function () {
        Route::prefix('menstrual-cycle')
            ->name('api.v1.menstrual-cycle.')
            ->controller(MenstrualCycleController::class)
            ->group(function () {
                Route::get('/status', 'status')->name('status');
                Route::post('/log', 'log')->name('log');
            });
    });
