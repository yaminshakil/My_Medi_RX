<?php

use App\Http\Controllers\Admin\Eprescriptions\AppointmentController;
use App\Http\Controllers\Admin\Eprescriptions\DoctorChamberController;
use App\Http\Controllers\Admin\Eprescriptions\InstructionController;
use App\Http\Controllers\Admin\Eprescriptions\ManufacturerController;
use App\Http\Controllers\Admin\Eprescriptions\MedicineController;
use App\Http\Controllers\Admin\Eprescriptions\MedicineDoseController;
use App\Http\Controllers\Admin\Eprescriptions\MedicineDurationController;
use App\Http\Controllers\Admin\Eprescriptions\PrescriptionController;
use App\Http\Controllers\Admin\Eprescriptions\VitalController;
use App\Http\Controllers\Api\V1\Prescriptions\PrescriptionVerificationController;
use Illuminate\Support\Facades\Route;

// Route::group(['middleware' => ['web', 'auth']], function () {
//     Route::get('appointments/create/{doctor_id}/{chamber_id?}', [AppointmentController::class, 'create'])->name('appointments.create_for_patient');
// });

Route::prefix('admin')->middleware(['web', 'auth', 'profile.exists', 'role.redirect:Admin,Doctor,Assistant,Patient'])->group(function () {
    Route::resource('prescriptions', PrescriptionController::class);
    Route::get('/eprescription/{uuid}/pdf', [PrescriptionController::class, 'downloadPdf'])
        ->name('eprescription.pdf');

    /* Appointments */
    Route::get('appointments/today', [AppointmentController::class, 'getTodaysAppointment'])->name('appointments.today');
    Route::get('appointments/new', [AppointmentController::class, 'getNewAppointment'])->name('appointments.new');
    Route::resource('appointments', AppointmentController::class);
    Route::post('appointments/changestatus', [AppointmentController::class, 'changeStatus'])->name('appointments.changestatus');
});

Route::prefix('admin')->middleware(['web', 'auth', 'profile.exists', 'role.redirect:Admin,Doctor'])->group(function () {
    Route::get('/get-medicines', [PrescriptionController::class, 'getAllMedicine'])
        ->name('prescription.allmedicine');
    Route::get('eprescriptions/followup/{id}/appointment/{appointment_id}', [PrescriptionController::class, 'followup'])->name('prescriptions.followup');
    Route::get('eprescriptions/create', [PrescriptionController::class, 'saveAndNewPrescription'])->name('prescriptions.saveandnew');
    Route::post('eprescriptions/saveandnew/create', [PrescriptionController::class, 'saveAndNewPrescriptionCreate'])->name('prescriptions.saveandnew.store');
    Route::post('eprescriptions/appointment/create/{patient_id}', [PrescriptionController::class, 'quickAppointment'])->name('prescriptions.saveandnew.quickAppointment');
    Route::get('eprescriptions/get-patients', [PrescriptionController::class, 'getAllPateint'])
        ->name('prescriptions.patients');
    Route::post('eprescriptions/createpatient', [PrescriptionController::class, 'createPatient'])
        ->name('prescriptions.createpatient');

    // Eprescription
    Route::get('/api/instructions', [InstructionController::class, 'index'])->name('admin.instruction.index');
    Route::post('/api/instructions', [InstructionController::class, 'store'])->name('admin.instruction.store');
    Route::put('/api/instructions/{instruction}', [InstructionController::class, 'update'])->name('admin.instruction.update');
    Route::delete('/api/instructions/{instruction}', [InstructionController::class, 'destroy'])->name('admin.instruction.destroy');
    Route::post('/api/instructions/reorder', [InstructionController::class, 'reorder'])->name('admin.instruction.reorder');
});

Route::prefix('admin')->middleware(['web', 'auth', 'profile.exists', 'role.redirect:Admin,Doctor,Assistant'])->group(function () {
    Route::resource('vitals', VitalController::class);
    Route::resource('medicine-doses', MedicineDoseController::class);
    Route::resource('manufacturers', ManufacturerController::class)->except(['create', 'edit', 'show']);
    Route::resource('medicine-durations', MedicineDurationController::class);
    Route::resource('medicines', MedicineController::class);

    Route::resource('chambers', DoctorChamberController::class);
    Route::get('switchchamber/{chamber_id}', [DoctorChamberController::class, 'switchChamber'])->name('switchchamber');
    Route::get('defaulthamber/{chamber_id}', [DoctorChamberController::class, 'switchChamber'])->name('chambers.setDefault');
});

Route::get(
    '/prescriptions/qr/{token}/pdf',
    [PrescriptionVerificationController::class, 'pdf']
)->name('prescriptions.qr.pdf');
Route::get('/prescriptions/verify/{token}', [PrescriptionVerificationController::class, 'verify'])->name('prescriptions.verify');
